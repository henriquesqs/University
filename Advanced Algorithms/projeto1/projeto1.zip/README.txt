# Siga as intruções a seguir para compilar e executar o programa

1. UTILIZAÇÃO COM MAKEFILE (supondo que o usuário já possua o Make instalado em sua máquina)
	
    - Abra um terminal na pasta gerada pela extração do .zip
    - Digite no terminal o comando: make all
    - Digite no terminal o comando: make run
    - Digite o nome do arquivo de texto (.txt) o qual desejas comprimir (por exemplo, lorem.txt)
    - Digite o nome do arquivo de texto comprimido (.txt)(por exemplo, loremcomprimido.txt)

