# Siga as intruções a seguir para compilar e executar o programa

1. UTILIZAÇÃO COM EXECUTÁVEL (supondo que o usuário já possua os compiladores g++ ou gcc instalados em sua máquina)
	
    - Abra um terminal na pasta gerada pela extração do .zip
    - Digite no terminal o comando abaixo para compilar o código: 
	Para g++ : g++ projeto2.cpp -o <nome_do_executavel>
	Para gcc : gcc projeto2.cpp -o <nome_do_executavel>    
    - Digite o comando abaixo para executar o código:
	./<nome_do_executavel>
    - Após isso, digite a entrada do programa de acordo com o que for solicitado por ele

